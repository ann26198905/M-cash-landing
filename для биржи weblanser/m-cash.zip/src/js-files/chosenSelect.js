$(document).ready(function() {
    $(".my_select_box").chosen({
        disable_search_threshold: 10,
        no_results_text: "Nothing found",
        placeholder_text_multiple: "Select Some Options",
        });
});